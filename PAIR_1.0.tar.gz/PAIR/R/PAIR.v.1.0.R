

#library(TeachingDemos)
#library(DNAcopy)

print("Loading libraries")
plot.m = function(data, col.i, chrs, cex.i, tit, xlab.i,ylab.i)
{
  if (missing(xlab.i) )  {xlab.i="Chromosome"}
  if (missing(ylab.i) )  {ylab.i="log-Ratio"}
  if (missing(cex.i) )  {cex.i=.1}
  if (missing(col.i) )
     {
      coli="black"
      ccol="red"
      acol="cyan"
     }  else

     {
      coli=col.i
      coli[col.i==1]="black"
      coli[col.i!=1]="red"
      ccol="yellow"
      acol="cyan"
     }

   if (length(data)%in%c(3,4))
      {
       LogRatio = data[[1]][,3]
      } else

      {
       LogRatio=data
      }

  plot (LogRatio,col=coli,xaxt="n",cex=cex.i, cex.lab = 1, cex.axis = .8, ylab="", xlab="")
  mtext(tit, 3, .8, cex=1.2, adj=0)
  mtext(xlab.i, 1, .8,cex=.8)
  mtext(ylab.i, 2,2.1,cex=.9)
  lbb=c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X")
  aatt=as.vector(cumsum(table(chrs)))/100
  maatt=((c(0,aatt[-length(aatt)])+aatt)/2 )[1:(length(aatt)-1)]
  axis (1, tick=TRUE, labels=F, at=c(0, aatt), lwd.ticks = 1, cex=.5, lwd=1)
  axis (1, line=-1, tick=F, labels=lbb, at=maatt,cex.axis=.6)


  if (length(data)%in%c(3,4))
	   {
	    dseg=data[[2]]
	    x=cbind(dseg[,3],dseg[,4])
	    y=cbind(dseg[,6],dseg[,6])

      for (w in 1:dim(dseg)[[1]])
		      {
           clipplot(lines(x[w,],y[w,], lwd = 2.5, col=ccol), xlim=c(x[w,1],x[w,2]))
          }
	   }
  abline(h=0, lwd= 2.3, col=acol)

}


plot.v = function(O, col, dlength, tit, chrs, axisTF)
{
if (missing(axisTF) )  {axisTF="Chromosome"}

 plot(O,cex=.1, xaxt="n",col=col)


if (length(unique(col))==1)
   {
    out=as.matrix(data.frame(start=1,end=dlength,n.marker=T,mean=0, sd=sd(O)))
   } else

   {
    outstate=stateseg(col,O)
    out=outstate[[1]]
   }

for (i in 1:dim(out)[[1]])
    {
     lines(c(out[i,1],out[i,2]),c(2*out[i,5],2*out[i,5]),col="red",lwd=3)
     lines(c(out[i,1],out[i,2]),c(-2*out[i,5],-2*out[i,5]),col="red",lwd=3)
    }

  mtext(tit,adj=0, 3, .8, cex=1.2)
  mtext("Chromosome", 1, .8,cex=.8)
  mtext("dalog-Ratio", 2,2.1,cex=.9)
  lbb=c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X")
  aatt=as.vector(cumsum(table(chrs)))
  maatt=((c(0,aatt[-length(aatt)])+aatt)/2 )[1:(length(aatt)-1)]

if (axisTF==F) {
               } else

               {
                axis (1, tick=TRUE, labels=F, at=c(0, aatt), lwd.ticks = 1, cex=.5, lwd=1)
                axis (1, line=-1, tick=F, labels=lbb, at=maatt,cex.axis=.6)
               }
  abline(h=0, col="cyan")
}

 plot.c = function(data, col.i, chrs, cex.i, tit, xlab.i,ylab.i,ylim.i)

{
if (missing(xlab.i))  {xlab.i="Chromosome"}
if (missing(ylab.i))  {ylab.i="log-Ratio"}
if (missing(cex.i) )  {cex.i=.1}
if (missing(col.i) )  {
                       coli="black"
                       ccol=7
                       acol=5
                      } else

                      {
                       coli=col.i
                       coli[col.i==1]="black"
                       coli[col.i!=1]="red"
                       ccol="yellow"
                       acol="cyan"
                      }

if (length(data)%in%c(3,4))
   {
    LogRatio=data[[1]][,3]
   } else

   {LogRatio=data}

if (missing(ylim.i))
   {
    plot (LogRatio,col=coli,xaxt="n",cex=cex.i, cex.lab = 1, cex.axis = .8, ylab="", xlab="")
   } else

   {plot (LogRatio,col=coli,xaxt="n",cex=cex.i, cex.lab = 1, cex.axis = .8, ylab="", xlab="",ylim=ylim.i)
   }

  mtext(tit, 3, .8, cex=1.2, adj=0)
  mtext(xlab.i, 1, .8,cex=.8)
  mtext(ylab.i, 2,2.1,cex=.9)
  lbb=c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X")
  aatt=as.vector(cumsum(table(chrs)))
  maatt=((c(0,aatt[-length(aatt)])+aatt)/2 )[1:(length(aatt)-1)]

  axis (1, tick=TRUE, labels=F, at=c(0, aatt), lwd.ticks = 1, cex=.5, lwd=1)
  axis (1, line=-1, tick=F, labels=lbb, at=maatt,cex.axis=.6)

 if (length(data)%in%c(3,4))
   {
    dseg=data[[2]]
    x=cbind(dseg[,3],dseg[,4])
    y=cbind(dseg[,6],dseg[,6])

    for (w in 1:dim(dseg)[[1]])
	 {
         clipplot(lines(x[w,],y[w,], lwd = 2.5, col=ccol), xlim=c(x[w,1],x[w,2]))
        }
   }
  abline(h=0, lwd= 1.5, col=acol)
}


hist.y = function(y,nn,bb, plotTF)
{
   if (missing(nn))  {nn=100}
   if (missing(bb))  {bb=nn}
   if (missing(plotTF))  {plotTF=F}

  mean=rep(NA,max(length(y))/nn)

for (i in 1:length(mean))
    {
     mean[i]=mean(y[((i-1)*nn+1):(i*nn)])
    }

  histmean=hist(mean, breaks=bb, plot=plotTF)
  out=list(mean,histmean)
}


mod.y = function(x, n.group, ite)
   {
    if (missing(ite)) {ite=30}

  n=length(x)
  p=rep(0.1,n.group)

  rg=max(x)-min(x)
  mu=seq((min(x)+rg/10),(max(x)-rg/10),length.out=n.group)


  sigma=rep(.2,n.group)
  theta=matrix(rep(NA,(n*n.group)),ncol=n.group)

for (k in 1:ite)
    {

     for (i in 1:n.group)
         { theta[,i]= p[i]*dnorm(x,mu[i],sqrt(sigma[i]))/0.9973002}
 
     theta.0=theta
     theta=theta/rowSums(theta)
     theta=theta*!is.na(theta)
	
     sigma2=rep(NA,n.group)
     for (i in 1:n.group)
         {p[i]=sum(theta[,i])/n
          mu[i]=sum((theta[,i]*x))/(n*p[i])
          sigma[i]=sum(theta[,i]*(x-mu[i])^2)/(n*p[i])
         }
 
     if (k>5) {inc=which(p>.05)
               sigma[inc]=sum((sigma[inc]*(round(p[inc]*n)-1)))/(round(sum(p[inc]*n))-1)
              }

     col=rep(NA,n)
     for (i in 1:n)
         {col[i]=which(theta[i,]==max(theta[i,]))
         }
    }
   
  lnL=0

for (j in 1:n)
    {
     lnL=lnL+log(sum(p*dnorm(x[j],mu,sqrt(sigma))))
    }
 
   par(mfrow=c(1,2))
   plot(x, col=col, cex=.3)

   ht=hist(x,999,col="blue", border="gray")
   out13=cbind(p,sigma)
   xxx=seq(min(x),max(x),.001)

for (i in 1:n.group)
    {
     xy=dnorm(xxx,mu[[i]],sqrt(sigma[i]))*p[i]*(max(ht[[2]])/dnorm(0,0,sqrt(rev(out13[order(out13[,1]),2])[1])))/max(p)
     points(xxx,xy,col="red",cex=.2)
    }

  BIC=-2*lnL+log(n)*(n.group-1+length(unique(mu))+length(unique(sigma)))
  out=list(p,mu,sigma,theta,theta.0,lnL,BIC,col)

  return(out)
}


segsd=function(out,O)
{
for (i in 1:dim(out)[[1]])
    {
     out[i,3]=out[i,2]-out[i,1]+1
     out[i,4]=mean(O[out[i,1]:out[i,2]])
     out[i,5]=sd(O[out[i,1]:out[i,2]])
     out[i,6]=mean(O[out[i,1]:out[i,2]]>0)
    }

  return(out)
}

segsdv=function(out,O,state)
{
for (i in 1:dim(out)[[1]])
    {
     out[i,3]=out[i,2]-out[i,1]+1
     out[i,4]=mean(O[out[i,1]:out[i,2]])
     out[i,5]=sd(O[out[i,1]:out[i,2]])
     out[i,6]=mean(O[out[i,1]:out[i,2]]>0)
     out[i,7]=mean(state[out[i,1]:out[i,2]])
    }
  return(out)
}


stateseg=function(state, O)
{
  T=length(state)
  segs2=c(1,as.matrix(c(which(state[-T]-state[-1]!=0)))+1)
  segs3=c(segs2[-1]-1,T)
  out=as.matrix(data.frame(start=segs2,end=segs3))

for (j in 2:(dim(out)[[1]]-1))
    {
     if ((out[j,2]-out[j,1]+1)<1)
        {
         if (mean(state[out[(j-1),1]:out[(j-1),2]])==mean(state[out[(j+1),1]:out[(j+1),2]]))
	     {
             state[out[j,1]:out[j,2]]=state[out[(j-1),1]]
	      out[j,1]=0
             out[(j+1),1]=0
             out[(j-1),2]=out[(j+1),2]
            } else
	              
            {	               
             if (abs(mean(O[out[(j-1),1]:out[(j-1),2]])-mean(O[out[j,1]:out[(j),2]]))>abs(mean(O[out[(j+1),1]:out[(j+1),2]])-mean(O[out[j,1]:out[(j),2]])))
	         {
                 out[j+1,1]=out[j,1]
                 if (out[(j+1),1]==0)   {out[(j+1),1]=out[(j+2),1]}
                 state[out[j,1]:out[j,2]]=state[out[(j+1),1]]
                } else
 
                {
                 out[j-1,2]=out[j,2]
                 if (out[(j-1),1]==0)   {out[(j-1),1]=out[(j-2),1]}
                 state[out[j,1]:out[j,2]]=state[out[(j-1),1]]
                }
                out[j,1]=0
             }
         }
     }

if ((out[1,2]-out[1,1])<1)
   {
    out[1,1]=0
    out[2,1]=1
   }

  out=out[out[,1]!=0,]
  out=as.matrix(data.frame(out,n.marker=NA,mean=NA, sd=NA, gt0=NA,state=NA))
  out=segsd(out,O)
  out=segsdv(out,O,state)
  outstate=list(out,state)

  return(outstate)
}

HMMvit = function(sd.2n, O, fac, plotTF)
{

if (missing(fac)) {fac=2}
if (missing(plotTF)) {plotTF=F}

  p=c(.8, .2)

  a1=t(c(.99999, .00001))
  a2=t(c(.0000001, .9999999))
  A=rbind(a1,a2)
  N=2
  T=length(O)

  M.msd=c(sd.2n, sd.2n*fac)
  which.w=ALF = matrix(rep(NA,T*N), T)
  state=which.w[,1]
  cct=rep(NA,T)

### ALF
  ALF[1,]=(c(dnorm(O[1], 0, M.msd[1]), sum(dnorm(O[1], M.msd[2], M.msd[1]),dnorm(O[1], -M.msd[2], M.msd[1]))))%*%diag(p)
  c0=sum(ALF[1,])
  which.w[1,]=0

  c0=1/c0
  ALF[1,]=c0*ALF[1,]

  cct[1]=c0

for (t in 2:T)
    {
     temp=diag(ALF[(t-1),])%*%A
     which.w[t,]=c(which(temp[,1]==max(temp[,1])), which(temp[,2]==max(temp[,2])))
     ALF[t,]=c(max(temp[,1]), max(temp[,2]))*c(dnorm(O[t], 0, M.msd[1]),sum(dnorm(O[t], M.msd[2],M.msd[1]),dnorm(O[t], -M.msd[2], M.msd[1])))  
     cct[t]=ct=1/sum(ALF[t,])
     ALF[t,]=ct*ALF[t,]
    }

  state[T]=which(ALF[T,]==max(ALF[T,]))

for (t in (T-1):1)
    {
     state[t]=which.w[t,state[t+1]]
    }

  state[1]=state[2]

if (length(unique(state))==1)
   {
    out=as.matrix(data.frame(start=1,end=T,n.marker=T,mean=0, sd=sd(O)))
   } else

   {
    outstate=stateseg(state,O)
    out=outstate[[1]]
    state=outstate[[2]]
   }


if (plotTF==T) 
   {
    plot(O,cex=.1, col=state) 

    for (i in 1:dim(out)[[1]])
        {lines(c(out[i,1],out[i,2]),c(2*out[i,5],2*out[i,5]),col="red",lwd=3)
         lines(c(out[i,1],out[i,2]),c(-2*out[i,5],-2*out[i,5]),col="red",lwd=3)
        }

    mtext("(a)",adj=0, 3, .8, cex=1.2)
    mtext("Chromosome", 1, .8,cex=.8)
    mtext("dalog-Ratio", 2,2.1,cex=.9)
    lbb=c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X")
    aatt=as.vector(cumsum(table(oo.ann[AB,2])))
    maatt=((c(0,aatt[-length(aatt)])+aatt)/2 )[1:(length(aatt)-1)]
    axis (1, tick=TRUE, labels=F, at=c(0, aatt), lwd.ticks = 1, cex=.5, lwd=1)
    axis (1, line=-1, tick=F, labels=lbb, at=maatt,cex.axis=.6)
    abline(h=0, col="cyan")
   }


  LnL0 = (dim(out)[[1]]-1)*log(T)-sum(log(1/cct))*2

  output=(list(out, state, LnL0))
  names(output)=c("out", "state", "LnL0")

  return (output)
}


PAIR=function(T.file, C.file, gt.file, ann.file, optionTF, plotTF)
{
if (missing(optionTF)) {optionTF=F}
if (missing(plotTF)) {plotTF=F}

  gt.data=read.table(gt.file, header=T, sep="\t")
  T.T=read.table(T.file, header=T, sep="\t")
  C.C=read.table(C.file, header=T, sep="\t")

if (mean(T.T[,5])>50) 
   {
    T.T[,4:5]=log2(T.T[,4:5])
    C.C[,4:5]=log2(C.C[,4:5])
   }

  n.data=log2(cbind(2^T.T[,4]+2^T.T[,5], 2^C.C[,4]+2^C.C[,5]))

  o.ann=read.table(ann.file, sep="\t", header=T)

  o2.ann=o.ann[order(o.ann[,1]),]
  o2.gt.data=gt.data[order(gt.data[,1]),]
  ann.gt=data.frame(o2.ann, o2.gt.data)

  oo.ann=ann.gt[order(ann.gt[,2], ann.gt[,3]),]
  nXY=sum(o.ann[,2]<=22)


if (dim(T.T)[[2]]>4) {T.T=T.T[, 4:5]}
if (dim(C.C)[[2]]>4) {C.C=C.C[, 4:5]}

  AA=oo.ann[,5]=="AA"
  AB=oo.ann[,5]=="AB"
  BB=oo.ann[,5]=="BB"
  chrs=oo.ann[,2]

  tAmB=(T.T[,1]-T.T[,2])[AB]
  cAmB=(C.C[,1]-C.C[,2])[AB]

HMMout_2=HMMvit(sd(T.T[,1]-T.T[,2])/5,(T.T[,1]-T.T[,2]))

stated02=HMMout_2[[2]]


  HMMout=HMMvit(sd(tAmB-cAmB),tAmB-cAmB)
  HMMout=HMMvit(sd((tAmB-cAmB)[HMMout[[2]]==1]),tAmB-cAmB)
  HMMout=HMMvit(sd((tAmB-cAmB)[HMMout[[2]]==1]),tAmB-cAmB, 2.1)

oAB=cbind(AB,seq(1,length(AB)))
roAB=oAB[oAB[,1]==1,]

state0=state02=state00=state000=rep(2,dim(T.T)[[1]])
statemean=state0[AB]

if (dim(HMMout[[1]])[[1]]==1) {
                               state0=state0*0+1
                               vot=HMMout[[1]]
                              } else

                              {
                               vot=HMMout[[1]]
                               vot1=vot[vot[,7]==1,]

                               for (k in 1:dim(vot)[[1]])
                                   {
                                    state0[roAB[vot[k,1],2]:roAB[vot[k,2],2]]=vot[k,7]
                                    vot[k,4]=mean((n.data[,1]-n.data[,2])[roAB[vot[k,1],2]:roAB[vot[k,2],2]])
                                    statemean[vot[k,1]:vot[k,2]]=(n.data[,1]-n.data[,2])[AB][vot[k,1]:vot[k,2]]
                                   }
                              }

  state0[stated02==1]=2
  hh00=hist.y((n.data[,1]-n.data[,2])[state0==1] )[[1]]
  mod1=mod.y(hh00,1)
  mod2=mod.y(hh00,2)

  hh=hist.y((n.data[,1]-n.data[,2]))[[1]]
  chrom=rep(1,length(hh))
  maploc=seq(1,length(hh))
  CNA.obj = CNA(hh,chrom, maploc)
  segsm = segment(CNA.obj)


  if (mod1[[7]]==min(mod1[[7]],mod2[[7]]))
     {
      medmu=mod1[[2]]
      state02=1
     } else

     {
      if (mod2[[7]]==min(mod1[[7]],mod2[[7]]))
         {
          medmu=mod2[[2]][order(mod2[[2]])][1]
          medmuupper=mod2[[2]][order(mod2[[2]])][2]
          }

          medvar=mean(diff(hh00)^2)/2
upper=medmu+8*sqrt(medvar)

      if (1>0)#(medmuupper-medmu)>.15)
         {
          vot2=segsm[[2]] [,c(3:4,6)]
          vot2[,1]=(vot2[,1]+1)*100+1-100
          vot2[,2]=(vot2[,2]*100+100)
          vot2[1,1]=1
          vot2[,2][vot2[,2]>length((n.data[,1]))]=length((n.data[,1]))


          for (i in 1:dim(vot2)[[1]])
              {
               if (i==1)
                  {
                   seg3n=rep(vot2[i,3],vot2[i,2]-vot2[i,1]+1)
                  } else

                  {
                   seg3n=c(seg3n,rep(vot2[i,3],vot2[i,2]-vot2[i,1]+1))}
                  }

      med3n=median(seg3n[(seg3n>medmu & seg3n<medmuupper&state0==2)])
      med1n=median(seg3n[(seg3n<medmu & state0==2)])

      if (is.na(med3n))
         {
          med3n=medmu+.58*abs(medmu-med1n)
         }

      if (is.na(med3n))
         {
          med3n=upper
         } else
         
         {med3n=max(med3n, upper)
         }

      vot2[,3]=((vot2[,3])>med3n)+1
      oAABB=cbind(1,seq(1,length(AB)))
      roAABB=oAABB[oAABB[,1]==1,]

      if (dim(segsm[[2]])[1]==1)
         {
          state02=state02*0+1
         } else

         {
          vot12=vot2[vot2[,3]==1,]
          for (k in 1:dim(vot2)[[1]])
              {
               state02[roAABB[vot2[k,1],2]:roAABB[vot2[k,2],2]]=vot2[k,3]
              }
         }

      if (dim(table(state02)) ==1)
         {
          state02=state02*0+1
         }
         } else

         {
          state02=1
         }
     }
      state00=(state0==2|state02==2)+1
      state000=state00

t=n.data[,1]
c=n.data[,2]
t=t-median(t[state000==1])
c=c-median(c[state000==1])

#################
if (optionTF!=F)
   {
  #M-A plot for adjusting for probe saturation;
  # M-A for tummor
  splineT=smooth.spline((T.T[,1]-T.T[,2])[state000==1],(n.data[,1])[state000==1])
  spT=predict(splineT,(T.T[,1]-T.T[,2]))

  pt2T=(t)-spT[[2]]+median(n.data[state000==1,1])
  t=pt2T

  #M-A for normal
  splineC<-smooth.spline((C.C[,1]-C.C[,2]), (n.data[,2]))
  spC=predict(splineC,(C.C[,1]-C.C[,2]))
  pt2C=(c)-spC[[2]]+median(n.data[,2])
  c=pt2C
   }
################

  t=t-median(t[state000==1])
  c=c-median(c[state000==1])

# M-A plot for log-Ratio
  splineTC=smooth.spline((t+c)[1:nXY][state000[1:nXY]==1], (t-c)[1:nXY][state000[1:nXY]==1])
  spTC=predict(splineTC,(t+c))

  norm.logR =(t-c)-spTC[[2]]

# Figure 1;
if (plotTF!=F)
   {
    plotchr = paste(out.path,"/PAIR.",IID,".jpg",sep="")
  jpeg(plotchr, 1000, 600)

  par(mfrow = c(2,2), oma = c(1,1,1,1), mar=c(2,4,2,1) )

    plot.v(tAmB-cAmB, HMMout[[2]], length(tAmB), chrs=chrs[AB], tit="(a)")
    plot.m(segsm, chrs=chrs, tit="(b)")
    plot.c(norm.logR, col=state0, chrs=chrs, tit="(c)")
    plot.c(norm.logR, col=state000, chrs=chrs, tit="(d)")

  dev.off()
   } else {}

  norm.logR=norm.logR

  return(norm.logR)

}
